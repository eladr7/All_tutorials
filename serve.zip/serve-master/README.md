# serve
1. yarn global add serve
2. From a folder's shell: serve
3. went to http://localhost:5000 (that was shown when ran 'serve')
4. Created a file: test.html in the folder that we ran 'serve' in, and refreshed the browser with the address http://localhost:5000 
5. searched google for 'html5 boilerplate' , but then went to http://www.example.com/ and did 'View page source' and copied the html into test.html
6. Removed what's in style, added a <script... in the and of <head> , inside body added the <input... and from the browser clicked test.html and saw the run.
