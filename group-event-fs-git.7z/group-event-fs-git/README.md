"# groupEventFStemplate" 
