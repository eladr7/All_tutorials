const CurrTab = {
  tabName: "Comedy",

  getTabName: function() {
    return this.tabName;
  },

  setTabName: function(tabName) {
    this.tabName = tabName;
  }
}

export default CurrTab;
