const Genres = ["Comedy", "Drama", "Fantasy"];

export default Genres;

// const Genres = {
//   Comedy: "Comedy",
//   Drama: "Drama",
//   Fantasy: "Fantasy"
// };