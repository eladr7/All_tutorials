import React from 'react';
import login from './pages/login/route';

const routes = [login];

export default routes;
