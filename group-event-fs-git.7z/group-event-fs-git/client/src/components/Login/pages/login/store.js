import form from '../../organism/login.form';

class Store {
  form = form;
}

export default Store;
