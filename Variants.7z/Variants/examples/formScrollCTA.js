var position = ["bottom", "left"];

var form;

// Gets form element.
if (twik_tags != null) {
  for (var twik_tag of twik_tags) {
    if (document.querySelector(twik_tag.selector) && twik_tag.value) {
      form = twik_tag.selector;
    }
  }
}

var formElement = document.querySelector(form);
var formRect;

// Get submit button of form.
var submitFormButton = [...formElement.querySelectorAll("input, button")].reduce((a, b) => {
  if (a.type) {
    if (a.type === "submit" || (a.type === "button" && b.type !== "button")) {
      return a;
    }
  }
  return b;
});
var submitFormButtonStyle;

// If found submit button, get its style.
if (submitFormButton.type && (submitFormButton.type === "submit" || submitFormButton.type === "button")) {
  submitFormButtonStyle = window.getComputedStyle(submitFormButton);
}
else {
  throw new Error("No submit found.");
}

// Create CTA.
var buttonElement = document.createElement("button");

// Get CTA style.
var buttonStyle = {
  display: "none",
  border: submitFormButtonStyle.border,
  borderRadius: submitFormButtonStyle.borderRadius,
  font: submitFormButtonStyle.font,
  backgroundColor: submitFormButtonStyle.backgroundColor,
  color: submitFormButtonStyle.color,
  position: "fixed",
  [position[0]]: "40px",
  [position[1]]: "40px",
  padding: submitFormButtonStyle.padding,
  width: submitFormButton.getBoundingClientRect().width,
  zIndex: Number.MAX_SAFE_INTEGER,
  cursor: submitFormButtonStyle.cursor,
  textTransform: submitFormButtonStyle.textTransform
};

// Apply CTA style.
for (var key in buttonStyle) {
  buttonElement.style[key] = buttonStyle[key];
}

// Add scroll onclick event to CTA.
buttonElement.addEventListener("click", () => {
  formRect = formElement.getBoundingClientRect();
  if (formRect.bottom <= 0) {
    window.scrollTo({
      top: Math.max(formElement.offsetTop - 40, 0),
      behavior: "smooth"
    });
  }
})

// Add text to CTA.
if (submitFormButton.value) {
  buttonElement.innerHTML = submitFormButton.value;
}
else {
  buttonElement.innerHTML = submitFormButton.innerHTML;
}

// Add CTA to body.
document.body.appendChild(buttonElement);

// Display CTA is form is off-screen.
function displayCTA() {
  formRect = formElement.getBoundingClientRect();
  if (formRect.bottom <= 0) {
    buttonElement.style.display = "block";
  }
  else {
    buttonElement.style.display = "none";
  }
}

// On scroll, run displayCTA.
window.addEventListener("scroll", displayCTA);

displayCTA();