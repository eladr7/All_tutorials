var maxSuggestions = 5;

var url = "https://suggestqueries.google.com/complete/search?client=firefox&q=";

// Function for getting JSONP.
function jsonp(uri) {
  return new Promise(function (resolve, reject) {
    var id = '_' + Math.round(10000 * Math.random());
    var callbackName = 'jsonp_callback_' + id;
    window[callbackName] = function (data) {
      delete window[callbackName];
      var ele = document.getElementById(id);
      ele.parentNode.removeChild(ele);
      resolve(data);
    }

    var src = uri + '&callback=' + callbackName;
    var script = document.createElement('script');
    script.src = src;
    script.id = id;
    script.addEventListener('error', reject);
    (document.getElementsByTagName('head')[0] || document.body || document.documentElement).appendChild(script)
  });
}

// Sets cookie and cookie's expiration date.
function setCookie(name, value, expireIn) {
  var d = new Date();
  d.setTime(d.getTime() + (expireIn * 24 * 60 * 60 * 1000));
  document.cookie = name + "=" + value + ";expires=" + d.toUTCString() + ";path=/;domain=" + window.location.hostname;
}

// Get's cookie's value.
function getCookie(name) {
  var cookieName = name + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var cookies = decodedCookie.split(';');
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i];
    while (cookie.charAt(0) == ' ') {
      cookie = cookie.substring(1);
    }
    if (cookie.indexOf(name) == 0) {
      return cookie.substring(cookieName.length, cookie.length);
    }
  }
  return "";
}

// Get search history from cookies.
var searchHistory = getCookie("searchHistory");
if (searchHistory) {
  searchHistory = JSON.parse(searchHistory);
}
else {
  searchHistory = [];
}

var input;

// Get input element.
if (twik_tags != null) {
  for (var twik_tag of twik_tags) {
    if (document.querySelector(twik_tag.selector) && twik_tag.value) {
      input = twik_tag.selector;
    }
  }
}

var inputElement = document.querySelector(input);
inputElement.autocomplete = "off";

// Create intellisense list.
var intellisnseUl = document.createElement("ul");

var inputStyle = window.getComputedStyle(inputElement);
// Style list based on input.
var ulStyle = {
  display: "none",
  listStyle: "none",
  border: inputStyle.border,
  font: inputStyle.font,
  backgroundColor: "#FFF",
  color: "#000",
  position: "absolute",
  top: window.scrollY + inputElement.getBoundingClientRect().bottom + "px",
  left: window.scrollX + inputElement.getBoundingClientRect().left + "px",
  width: inputStyle.width,
  zIndex: Number.MAX_SAFE_INTEGER,
}

for (var key in ulStyle) {
  intellisnseUl.style[key] = ulStyle[key];
}

// Add list to body.
document.body.appendChild(intellisnseUl);

// Styling for hovering over list items.
const styleTag = document.createElement("style");
styleTag.innerHTML = ".autocompleteHoverClass:hover{background-color: #DDD;} .autocompleteHoverClass{padding: 8px;}";
document.head.insertAdjacentElement('beforeend', styleTag);

// When the value of the input changes...
inputElement.addEventListener("input", e => {
  if (intellisnseUl.style.top !== window.scrollY + inputElement.getBoundingClientRect().bottom + "px") {
    intellisnseUl.style.top = window.scrollY + inputElement.getBoundingClientRect().bottom + "px";
  }

  if (intellisnseUl.style.left !== window.scrollX + inputElement.getBoundingClientRect().left + "px") {
    intellisnseUl.style.left = window.scrollX + inputElement.getBoundingClientRect().left + "px";
  }

  if (intellisnseUl.style.width !== window.getComputedStyle(inputElement).width) {
    intellisnseUl.style.width = window.getComputedStyle(inputElement).width;
  }

  // Get google autocomplete results.
  jsonp(url + e.target.value)
    .then(res => res[1])
    .then(res => {
      // Display list.
      intellisnseUl.style.display = "block";
      // Remove all previous children from list.
      while (intellisnseUl.firstChild) {
        intellisnseUl.removeChild(intellisnseUl.firstChild);
      }

      // Create list of suggestions based on google results and search history.
      var suggestions = searchHistory.filter(value => value.includes(e.target.value));
      suggestions = suggestions.concat(res.filter(value => !suggestions.includes(value)));

      // Add all suggestions to list.
      for (var i = 0; i < Math.min(maxSuggestions, suggestions.length); i++) {
        var listItem = document.createElement("li");
        listItem.innerHTML = suggestions[i];
        listItem.className = "autocompleteHoverClass";
        // On click apply suggestion to input and stop displaying list.
        listItem.addEventListener("click", e => {
          inputElement.value = e.target.innerHTML;
          intellisnseUl.style.display = "none";
          currentFocus = -1;
        })

        // Add suggestions to list
        intellisnseUl.appendChild(listItem);
      }
    })
    // If error, don't display list.
    .catch(() => { intellisnseUl.style.display = "none" });
});

var currentFocus = -1;
// On key pressed...
inputElement.addEventListener("keydown", e => {
  // On up or down presses, change active suggestion.
  if (e.keyCode == 40) {
    if (currentFocus >= 0)
      intellisnseUl.children[currentFocus].style.backgroundColor = ulStyle.backgroundColor;
    currentFocus++;
    if (currentFocus >= intellisnseUl.children.length) {
      currentFocus = 0;
    }
    intellisnseUl.children[currentFocus].style.backgroundColor = "#DDD";
  }
  else if (e.keyCode == 38) {
    if (currentFocus >= 0)
      intellisnseUl.children[currentFocus].style.backgroundColor = ulStyle.backgroundColor;
    currentFocus--;
    if (currentFocus < 0) {
      currentFocus = intellisnseUl.children.length - 1;
    }
    intellisnseUl.children[currentFocus].style.backgroundColor = "#DDD";
  }
  // On return...
  else if (e.keyCode == 13) {
    // If any suggestion is active, apply suggestion to input and stop displaying list.
    if (currentFocus >= 0) {
      e.preventDefault();
      inputElement.value = intellisnseUl.children[currentFocus].innerHTML;
      intellisnseUl.style.display = "none";
      currentFocus = -1;
      return false;
    }
    // Otherwise, add to search history cookie and submit.
    else {
      if (!searchHistory.includes(inputElement.value)) {
        searchHistory.unshift(inputElement.value);
      }
      setCookie("searchHistory", JSON.stringify(searchHistory), 365);
    }
  }
})

// On click stop displaying list.
document.addEventListener("click", function (e) {
  intellisnseUl.style.display = "none";
});