var styles = document.createElement("style");
styles.innerText = ".stickyHeader {\
  position: fixed;\
  top: 0;\
  width: 100%;\
}";
document.body.appendChild(styles);

var header;

// Gets form element.
if (twik_tags != null) {
  for (var twik_tag of twik_tags) {
    if (document.querySelector(twik_tag.selector) && twik_tag.value) {
      header = twik_tag.selector;
    }
  }
}

var headerElement = document.querySelector(header);
var headerOffset = headerElement.offsetTop;

function toStickyHeader() {
  if (window.pageYOffset > headerOffset) {
    headerElement.classList.add("stickyHeader");
  }
  else {
    headerElement.classList.remove("stickyHeader");
  }
}

window.addEventListener("scroll", toStickyHeader);