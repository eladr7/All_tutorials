// The different languages URLs of the site
const urls = [
    {
        'language'  : 'Russian',
        'iso_code'  : 'RU',
        'url'       : 'https://www.playbuzz.com/quizzes/russian'
    },
    {
        'language'  : 'English',
        'iso_code'  : 'US',
        'url'       : 'https://www.playbuzz.com/quizzes'
    },
    {
        'language'  : 'Hebrew',
        'iso_code'  : 'IL',
        'url'       : 'https://www.playbuzz.com/quizzes/hebrew'
    }
];

const lngRdrctCookieName = '_twik_language_remember';

const getTheSiteUrlOfTheCountryTheUserIsIn = function(urls) {
    // If twik_user_data was sent, get from it the current country the user is in right now.
    // By default, assume the site should be in English.
    let iso_code = 'US';
    // if(twik_user_data){
    //     iso_code = twik_user_data.location.iso_code;
    // }

    // Get the URL of the site for the country the user is in right now.
    let url = '';
    for(let item of urls){
        if(item.iso_code == iso_code){
            url = item.url;
        }
    }

    return url;
}

const setCookie = (cookieName, cookieValue) => {
    document.cookie = cookieName + "=" + cookieValue + ";";
}

const createLanguageRedirectModal = function(currentCountrySiteUrl) {
    let cel = document.createElement('div');
    let cstr = document.createElement('p');
    let cbtny = document.createElement('button');
    let cbtnn = document.createElement('button');
    let cbtnd = document.createElement('button');
    cel.append(cstr, cbtny, cbtnn, cbtnd);

    cel.classList.add('language-cookie');

    cstr.innerText = "Do you want to translate the site to your local language?";
    cbtny.innerText = "Yes";
    cbtnn.innerText = "No thanks";
    cbtnd.innerText = "Dismiss";

    cel.setAttribute('style', 'position: fixed; bottom: 0; width: 100%; background: #eee; text-align: center;');
    cstr.setAttribute('style', 'text-align: center; font-size: 1.2em; margin: 20px 0 0 0;');
    cbtny.setAttribute('style', 'border: 1px solid; margin: 20px; width: 100px; padding: 5px; background: transparent; outline: none; color: red;');
    cbtnn.setAttribute('style', 'border: 1px solid; margin: 20px; width: 100px; padding: 5px; background: transparent; outline: none; color: red;');
    cbtnd.setAttribute('style', 'border: 1px solid; margin: 20px; width: 100px; padding: 5px; background: transparent; outline: none; color: red;');

    cbtny.onclick = () => {
        setCookie(lngRdrctCookieName, 'yes');
        window.location.assign(currentCountrySiteUrl);
        cel.setAttribute('style', 'display: none');
    };
    cbtnn.onclick = () => {
        setCookie(lngRdrctCookieName, 'no');
        cel.setAttribute('style', 'display: none');
    };
    cbtnd.onclick = () => {
        cel.setAttribute('style', 'display: none');
    };

    return cel;
}

const getCookieValueByName = (cookieName) => {
    let name = cookieName + "=";
    
    let cookiesArray = document.cookie.split(';');
    for(let i = 0; i < cookiesArray.length; i++) {
        let cookieLine = cookiesArray[i];

        let j = 0;
        while(cookieLine[j] == ' ') j++;
        cookieLine = cookieLine.substring(j);

        if (cookieLine.indexOf(name) == 0) {
            return cookieLine.substring(name.length, cookieLine.length);
        }
    }

    return "";
}

const checkLanguageRedirect = function () {
    let currentCountrySiteUrl = getTheSiteUrlOfTheCountryTheUserIsIn(urls);

    const lngRdrctCookieValue = getCookieValueByName(lngRdrctCookieName);
    switch (lngRdrctCookieValue) {
        case 'yes':
            // The user chose to get redirected to the site of the current country he's in,
            // and he's currently in a site of another country, so redirect him to the URL
            // of the site of the country he's currently in.
            if(currentCountrySiteUrl !== window.location.href){
                window.location.assign(currentCountrySiteUrl);
            }
            break;
        case 'no':
            // The user chose to not get redirected, so do nothing.
            break;
        default:
            // This cookie wasn't assigned; thus append the language redirect modal
            if(currentCountrySiteUrl !== window.location.href){
                const languageRedirectModal = createLanguageRedirectModal(currentCountrySiteUrl);
                document.body.append(languageRedirectModal);
            }
            break;
    }
}

// document.addEventListener('DOMContentLoaded', checkLanguageRedirect);
checkLanguageRedirect();