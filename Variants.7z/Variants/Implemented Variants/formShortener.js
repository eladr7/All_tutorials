const attributesToSearchBy = ['id', 'name', 'data-name', 'palceholder'];
const firstNameRegex = "[fF](irst|rst).*[nN](ame|m)";
const lastNameRegex = "[lL](ast|st).*[nN](ame|m)";
const emailRegex = "([uU](ser|sr))?.*[eE](mail|ml)";
const companyRegex = "[cC](ompany|mpny|mpn)";
const companySelectRegex = "[cC](ompany|mpny|mpn).*([tT](ype)|[sS](elect|lct))";
const phoneRegex = "[pP](hone|hn)";

// ************************
// The code execution part:
// ************************
var $;
if (window.jQuery)
{
    window.addEventListener("load", runTheFormShortener, false);
    // runTheFormShortener();
}
else
{
    window.addEventListener("load", loadJqueryAndThenRunTheFormShortener, false);
    // loadJqueryAndThenRunTheFormShortener();
}

function runTheFormShortener() {
    $ = jQuery.noConflict();
    $(document).ready(function () {
        setTimeout(function () {
            setCurrentCountryInRelevantSelectors();
    
            shortenForms();
        }, 1);
    });
}

function loadJqueryAndThenRunTheFormShortener() {
    function loadScript(url, callback) {
        var script = document.createElement("script")
        script.type = "text/javascript";

        if (script.readyState) { //IE
            script.onreadystatechange = function () {
                if (script.readyState == "loaded" || script.readyState == "complete") {
                    script.onreadystatechange = null;
                    callback();
                }
            };
        } else { //Others
            script.onload = function () {
                callback();
            };
        }

        script.src = url;
        document.getElementsByTagName("head")[0].appendChild(script);
    }

    loadScript("https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js", function () {
        //jQuery loaded
        runTheFormShortener();
    });
}

function setCurrentCountryInRelevantSelectors() {
    var currentLocationObj = window.twik_user_data.location;
    var selectTags = document.getElementsByTagName('select');
    var dom, domState;
    for (var i = 0; i < selectTags.length; i++) {
        for (var j = 0; j < selectTags[i].length; j++) {
            if (selectTags[i][j].value.toLowerCase() == currentLocationObj.country.toLowerCase()) {
                dom = selectTags[i];
            }
            if (currentLocationObj.state !== null && selectTags[i][j].value.toLowerCase() == currentLocationObj.state.toLowerCase()) {
                domState = selectTags[i];
            }
        }
    }

    var countries = [];
    if (dom) {
        for (var i = 0; i < dom.length; i++) {
            countries.push(dom[i].value);
        }
        if (dom[0].value.length == 2) {
            dom[countries.indexOf(currentLocationObj.iso_code.toLowerCase())].selected = true;
        }
        else {
            for (var i = 0; i < countries.length; i++) {
                if (countries[i].toLowerCase().indexOf(currentLocationObj.country.toLowerCase()) != -1) {
                    dom[i].selected = true;
                }
            }
        }
    }

    var states = [];
    if (domState) {
        for (var i = 0; i < domState.length; i++) {
            states.push(domState[i].value);
        }
        for (var i = 0; i < states.length; i++) {
            if (states[i].toLowerCase().indexOf(currentLocationObj.state.toLowerCase()) != -1) {
                dom[i].selected = true;
            }
        }
    }
}

function shortenForms() {
    // Currently will return only one form and not an array
    var form = getgetUserDetailsFormsFromTwikTags();
    if (!form || form.length === 0) {
        form = getUserDetailsForms();
    }

    $(form).each(function () {
        let $form = $(this);
        $form.removeAttr('novalidate');

        let { $firstNameInput, tempFirstName } = handleFirstLastNameCombining($form);

        handleEmailAndCompanyCombining($form);

        let $submitElement = getFormSubmitElement($form);
        $submitElement.click(() => {
            $form.find('input,select,textarea').change();
            event.preventDefault();

            // The reason for this line, is that at this point, the hidden last-name input contains
            // only the last name, but the first-name input contains both the first and last name.
            // Notice that tempFirstName contains only the first name.
            $firstNameInput.val(tempFirstName);

            $(this).unbind('submit').submit();
        });
    });
}

function getUserDetailsForms() {
    // Find the form that contains an element with an attribute or text that contains some sort of
    // 'first name' mentionning.
    let $matchingElement = getElementWithAttrMatchingRegex('form', '*', firstNameRegex);
    if ($matchingElement) return $matchingElement[0].closest("form");

    var regex = new RegExp(firstNameRegex);
    let $matchingformChildrenByText = $("form").find('*').filter(function () {
        return regex.test($(this).text());
    });

    if ($matchingformChildrenByText && $matchingformChildrenByText.length > 0) {
        return $matchingformChildrenByText[0].closest("form");
    }

    return null;
}

function getgetUserDetailsFormsFromTwikTags() {
    var desiredSelector;

	if (twik_tags != null) {
	    for (var twik_tag of twik_tags) {
	      if (document.querySelector(twik_tag.selector) && twik_tag.name.includes('frm-shrt')) {
	        desiredSelector = twik_tag.selector;
	      }
		}
	}

	var desiredElements = document.querySelectorAll(desiredSelector);
	return desiredElements;
}

function handleFirstLastNameCombining($form) {
    var $firstNameInput = getMatchingFormField($form, 'input', firstNameRegex);
    var $lastNameInput = getMatchingFormField($form, 'input', lastNameRegex);

    combineFirstLastToFullName($firstNameInput, $lastNameInput);

    var tempFirstName = setFirstLastNameOnFullNameChange($firstNameInput, $lastNameInput);

    return { $firstNameInput: $firstNameInput, tempFirstName };
}

function getMatchingFormField($form, fieldType, regexString) {
    let $formInput = getElementWithAttrMatchingRegex($form, fieldType, regexString);

    if ($formInput) return $formInput;

    // The form has no child with a last name attribute value; thus search for a last name text.

    var $matchedElement = getChildElementWithStringMatchingRgx($form, regexString);
    if ($matchedElement) {
        const $nextSibling = $matchedElement.next();
        if ($nextSibling.is(fieldType)) return $nextSibling;

        return $matchedElement.parent().children(fieldType).first();
    }

    return null;
}

function getElementWithAttrMatchingRegex(contextElement, elementType, regex) {
    let result = undefined;

    $.each(attributesToSearchBy, function (i, attributeName) {
        let $matchingElements = $(contextElement).find(elementType).filter(function () {
            let attribute = $(this).attr(attributeName);
            if (attribute) {
                return attribute.match(regex);
            }
            return false;
        });
        if ($matchingElements && $matchingElements.length > 0) {
            result = $matchingElements;
            return false;
        }
    });

    return result;
}

function combineFirstLastToFullName($firstNameInput, $lastNameInput) {
    $firstSiblingParents = getFirstSiblingParents($firstNameInput, $lastNameInput);

    // Change the title/placeholder for the first name input field
    changeFirstNameInputToFullName($firstNameInput, $firstSiblingParents[0]);

    // Hide the last name input field
    $firstSiblingParents[1].hide();
    // let $firstNameParent = getInputOrParent($lastNameInput, lastNameRegex);
    // $firstNameParent.hide();
}

function changeFirstNameInputToFullName($firstNameInput, $firstNameParent) {
    // var $firstNameParent = getFirstNameInputOrParent($firstNameInput);
    const $firstNameInputParent = $firstNameInput.parent();

    if ($firstNameInputParent.is('form')) {
        // The first name input field is a direct child of the form

        $firstNameInput.css({ width: '100%' });

        var regex = new RegExp(firstNameRegex);
        let $prev = $firstNameInput.prev();
        if (regex.test($prev.text())) {
            $prev.css({ width: '100%' });
        } else {
            // The 'first name' text is $firstNameInput's placeholder
            $firstNameInput.attr("placeholder", "Full name (first then last)");
        }

        // Append an explanation paragraph
        let $fullNameInstructionP = $('<p id="full-name-guide">If your first and/or last name contain more than one word,\n insert them as such: Mary-May-Anne González-Rodríguez</p>');
        $fullNameInstructionP.css({ width: '100%' });
        $firstNameInput.after($fullNameInstructionP);
    } else {
        // const $firstNameParent = getTopParentUnderForm($firstNameInput);

        $firstNameParent.css({ width: '100%' });

        var $firstNameTitle = getChildElementWithStringMatchingRgx($firstNameParent, firstNameRegex);
        if ($firstNameTitle && $firstNameTitle.length > 0) {
            $firstNameTitle.html('Full name (first then last)');
        } else {
            // The 'first name' text is $firstNameInput's placeholder
            $firstNameInput.attr("placeholder", "Full name (first then last)");
        }

        // Append an explanation paragraph
        let $fullNameInstructionP = $('<p id="full-name-guide">If your first and/or last name contain more than one word,\n insert them as such: Mary-May-Anne González-Rodríguez</p>');
        $firstNameParent.append($fullNameInstructionP);
    }
}

function getFirstSiblingParents($e1, $e2) {
    let d1 = getDepth($e1);
    let d2 = getDepth($e2);

    if (d1 > d2) {
        $e1 = advanceUp($e1, d1 - d2);
    } else {
        $e2 = advanceUp($e2, d2 - d1);
    }

    let $sibling1 = $e1.parent();
    let $sibling2 = $e2.parent();

    if ($sibling1.is($sibling2)) {
        return [$e1, $e2];
    }

    let $parent1 = $sibling1;
    let $parent2 = $sibling2;
    while (!$parent1.is($parent2)) {
        $sibling1 = $parent1;
        $sibling2 = $parent2;

        $parent1 = $parent1.parent();
        $parent2 = $parent2.parent();
    }

    return [$sibling1, $sibling2];
}

function getDepth($element) {
    let depth = 1;
    let $parent = $element.parent();
    while (!$parent.is('form')) {
        $parent = $parent.parent();
        depth++;
    }

    return depth;
}

function advanceUp($element, steps) {
    let $parent = $element;
    while (steps > 0) {
        $parent = $parent.parent();
        steps--;
    }

    return $parent;
}

function getTopParentUnderForm($element) {
    let $parent = $element.parent();
    let $result = $parent;
    while (!$parent.is('form')) {
        $result = $parent;
        $parent = $parent.parent();
    }

    return $result;
}

function getInputOrParent($inputField, regexString) {
    let $parent = $inputField.parent();

    if ($parent.is('form')) {
        let $prev = $inputField.prev();

        var regex = new RegExp(regexString);
        if (regex.test($prev.text())) {
            return $prev;
            // $prev.hide();
        }

        return $inputField;
        // $inputField.hide();
    } else {
        $parent = getTopParentUnderForm($inputField);
        return $parent;
        // $parent.hide();
    }
}

function getChildElementWithStringMatchingRgx($parentElement, regexString) {
    var regex = new RegExp(regexString);

    let $matchedElement = $parentElement.find('*').filter(function () {
        return regex.test($(this).text());
    });

    if ($matchedElement && $matchedElement.length > 0) {
        return $matchedElement;
    }

    return null;
}

function setFirstLastNameOnFullNameChange($firstNameInput, $lastNameInput) {
    const fullNameRgx = '.+\\s.+';
    var tempFirstName = '';

    $firstNameInput.on('change keyup blur', function (e) {
        var fullNameString = $firstNameInput.val();
        if (RegExp(fullNameRgx).test(fullNameString)) {
            var fullNameArray = fullNameString.split(' ');

            if (fullNameArray.length === 2) {
                tempFirstName = fullNameArray[0].replace('-', ' ');
                $lastNameInput.val(fullNameArray[1].replace('-', ' '));
                $('#full-name-guide').css('color', 'unset');
            } else {
                $firstNameInput.val("");
                $lastNameInput.val("");
                $('#full-name-guide').css('color', 'red');
            }
        }
    });

    return tempFirstName;
}

function handleEmailAndCompanyCombining($form) {
    var arrEmail = ['gmail.com', 'icloud.com', 'mail.com', 'mail.ru', 'aol.com', 'yahoo.com', 'zoho.com', 'outlook.com', 'gmx.com', 'lycos.com', 'yandex.com'];

    let $emailInput = getMatchingFormField($form, 'input', emailRegex);

    let $companyInput = getMatchingFormField($form, 'input', companyRegex);
    let $companyParent = getInputOrParent($companyInput);
    $companyParent.hide();

    let $companySelectParent = getCompanySelectParent($form);

    var $phoneParent = enlargePhoneInput($form);

    // If the inserted email is not a company email, but is rather one of the known emails
    // like gmail, set 'show' to true
    let show = false;
    $.each(arrEmail, function (i, item) {
        if ($emailInput.val().indexOf("@" + item) > 0) {
            show = true;
            return false;
        }
    });

    // When typing the email, if it's not a company email, return the company fields
    $emailInput.on('change', function () {
        show = false;
        var text = $(this).val();
        $.each(arrEmail, function (i, item) {
            if (text.indexOf("@" + item) > 0) {
                show = true;
                return false;
            }
        });

        if (show) {
            if ($companyInput.is(":hidden")) $companyParent.show();
            if ($companySelectParent) $companySelectParent.show();
            $phoneParent.css({ width: '50%' });
        }
        else {
            $companyParent.hide();
            if ($companySelectParent) $companySelectParent.hide();
            $phoneParent.css({ width: '100%' });
            var companyNameArr = text.match(/.+@([^\.]+)\./);
            if (companyNameArr) {
                $companyInput.val(companyNameArr[1]);
            }
        }
        $companyInput.toggle(show);
    });
}

function getCompanySelectParent($form) {
    let $companySelectParent = undefined;
    let $companySelect = getMatchingFormField($form, 'select', companySelectRegex);
    if ($companySelect) {
        $companySelectParent = getInputOrParent($companySelect);
        $companySelectParent.hide();
    }
    return $companySelectParent;
}

function enlargePhoneInput($form) {
    let $phoneParent = undefined;
    var $phoneInput = getMatchingFormField($form, 'input', phoneRegex);
    if ($phoneInput) {
        $phoneParent = getInputOrParent($phoneInput);
        $phoneParent.css({ width: '100%' });
    }

    return $phoneParent;
}

function getFormSubmitElement($form) {
    // if found type=submit, good.
    // else: search the document for:  for="form.id" and do it on this element

    let submitElement = $form.find('[type="submit"]');
    if (submitElement) return submitElement;

    // The form doesn't have an element with the type="submit" attribute

    let formId = $form.attr('id');
    return $('[for="' + formId + '"]');
}

// function redoForm() {
//     var newScript = document.createElement("script");

//     newScript.type = 'text/javascript';
//     newScript.innerText = '\
//     var formScript = document.querySelector("script[data-hubspot-rendered=true]").innerHTML;\
//     var formScriptObjectString = formScript.substring(formScript.indexOf("(") + 1, formScript.lastIndexOf(")"));\
//     var formScriptObject = JSON5.parse(formScriptObjectString);\
//     \
//     formScriptObject.blockedDomains = ["gmail.com", "icloud.com", "mail.com", "mail.ru", "aol.com", "yahoo.com", "zoho.com", "outlook.com", "gmx.com", "lycos.com", "yandex.com"];\
//     hbspt.forms.create(formScriptObject);\
//     ';
//     var formElement = document.querySelector(".hbspt-form");
//     formElement.parentElement.insertBefore(newScript, formElement);
//     formElement.parentElement.removeChild(formElement);
// }

// window.addEventListener("load", () => {
//     var jsonLib = document.createElement("script");
//     jsonLib.src = "https://unpkg.com/json5@^2.0.0/dist/index.min.js";
//     document.body.appendChild(jsonLib);
//     jsonLib.addEventListener("load", redoForm);
// });