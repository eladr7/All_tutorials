var position = "right";
var language = "en";
window.addEventListener("load", () => {
    var script = document.createElement("script");
    script.src =
		"https://cdn.jsdelivr.net/gh/mickidum/acc_toolbar/acctoolbar/acctoolbar.min.js";
		
    (
        document.getElementsByTagName("head")[0] ||
        document.body ||
        document.documentElement
	).appendChild(script);
	
    script.addEventListener("load", () => {
		(function() {
			setTimeout(function() {
				window.micAccessTool = new MicAccessTool({
					buttonPosition: position,
					forceLang: language
				});
			}, 700);
		  })();
	});
});
