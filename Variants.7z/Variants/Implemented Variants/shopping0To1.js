runChange0To1();

// If your site doesn't have the jquery script, comment out the line above: runTheFormShortener();
// and uncomment this line below (i.e. loadJqueryAndThenRunThenChange0To1();)
// loadJqueryAndThenRunThenChange0To1();

var $;
function runChange0To1() {
    $ = jQuery.noConflict();
    $(document).ready(function () {
        setTimeout(function () {
            change0To1();
        }, 1);
    });
}

function loadJqueryAndThenRunThenChange0To1() {
    function loadScript(url, callback) {
        var script = document.createElement("script")
        script.type = "text/javascript";

        if (script.readyState) { //IE
            script.onreadystatechange = function () {
                if (script.readyState == "loaded" || script.readyState == "complete") {
                    script.onreadystatechange = null;
                    callback();
                }
            };
        } else { //Others
            script.onload = function () {
                callback();
            };
        }

        script.src = url;
        document.getElementsByTagName("head")[0].appendChild(script);
    }

    loadScript("https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js", function () {
        //jQuery loaded
        runChange0To1();
    });
}


function change0To1() {
    $("input").filter(function() {
		var inputValue = $(this).val();

		if (inputValue === '0') {
			$(this).val('1');
		}
		if (inputValue === 0) {
			$(this).val(1);
		}
    });
}
