// ************************
// Adjustable options:
// ************************
// Enter the correct input for the field
const correctInput = "cal";

// Enter the validation component type.
// there are two options: "select" or "input".
const validationComponentType = "select";

// Enter the correct validation value.
const correctValidationValue = "3333";

// Enter the validation options in the following format:
// optionName: 0 --> for an invalid option.
// optionName: 1 --> for a valid option.
//
// Note: First option is the placeholder for the drop down menu.
// (i.e. the "Select an option": 0)
const selectValidationOptions = new Map();
selectValidationOptions.set("Select an option", 0);
selectValidationOptions.set("1111", 0);
selectValidationOptions.set("2222", 0);
selectValidationOptions.set(correctValidationValue, 1);
selectValidationOptions.set("4444", 0);


// ************************
// CSS id names:
// ************************
const validationOptionsContainerId = "validation-object";
const validationOptionsModalId = "validation-modal";
const validationOptionsSelectFormId = "example";
const validationOptionsSelectId = "field";
const validationErrorContainerId = "error-popup-container";


// ************************
// CSS styles:
// ************************
// Dropdown styles:
const twikVariantPopupContainer = {
    position: "absolute",
    // left: "0%",
    // top: "0%",
    // right: "0%",
    // bottom: "0%",
    left: "35%",
    top: "25%",
    display: "-webkit-box",
    display: "-webkit-flex",
    display: "-ms-flexbox",
    display: "none", // What the user enters the right coupon code, display changes to "flex"
    "-webkit-box-pack": "center",
    "-webkit-justify-content": "center",
    "-ms-flex-pack": "center",
    justifyContent: "center",
    "-webkit-box-align": "center",
    "-webkit-align-items": "center",
    "-ms-flex-align": "center",
    alignItems: "center",
    // backgroundColor: "rgba(0, 0, 0, 0.36)"
};

const twikVariantActualPopup = {
    display: "-webkit-box",
    display: "-webkit-flex",
    display: "-ms-flexbox",
    display: "flex",
    maxWidth: "260px",
    marginRight: "18px",
    marginLeft: "18px",
    padding: "24px",
    "-webkit-box-orient": "vertical",
    "-webkit-box-direction": "normal",
    "-webkit-flex-direction": "column",
    "-ms-flex-direction": "column",
    flexDirection: "column",
    "-webkit-box-pack": "center",
    "-webkit-justify-content": "center",
    "-ms-flex-pack": "center",
    justifyContent: "center",
    "-webkit-box-align": "center",
    "-webkit-align-items": "center",
    "-ms-flex-align": "center",
    alignItems: "center",
    borderRadius: "2px",
    backgroundColor: "#fff",
    boxShadow: "0 2px 8px 0 rgba(0, 0, 0, 0.18)",
    textAlign: "center",
};

const twikModal = {
    display: "none", /* Hidden by default */
    position: "fixed", /* Stay in place */
    zIndex: "1", /* Sit on top */
    paddingTop: "100px", /* Location of the box */
    left: "0",
    top: "0",
    width: "100%", /* Full width */
    height: "100%", /* Full height */
    overflow: "auto", /* Enable scroll if needed */
    backgroundColor: "rgb(0,0,0)", /* Fallback color */
    backgroundColor: "rgba(0,0,0,0.4)" /* Black w/ opacity */
}

const twikVariantTitle = {
    marginTop: "8px",
    marginBottom: "8px"
};

const twikVariantSelectField = {
    width: "100%",
    marginBottom: "0px"
};

const twikVariantIcon = {
    width: "56px",
    height: "56px"
};

const twikVariantP = {
    marginBottom: "36px"
};

// Error message styles:
const twikVariantErrorPopupContainer = {
    position: "absolute",
    // left: "0%",
    // top: "0%",
    // right: "0%",
    // bottom: "0%",
    left: "120%",
    top: "20%",
    display: "-webkit-box",
    display: "-webkit-flex",
    display: "-ms-flexbox",
    display: "none", // What the user enters the right coupon code, display changes to "flex"
    "-webkit-box-pack": "center",
    "-webkit-justify-content": "center",
    "-ms-flex-pack": "center",
    justifyContent: "center",
    "-webkit-box-align": "center",
    "-webkit-align-items": "center",
    "-ms-flex-align": "center",
    alignItems: "center",
    // backgroundColor: "rgba(0, 0, 0, 0.36)"
};

const twikVariantPopupClose = {
    position: "absolute",
    width: "18px",
    height: "18px",
    opacity: "0.44"
};

const twikVariantParagraphMargin = {
    marginBottom: "24px"
};

// The object mapping class names to the JS class-objects:
const classNameToClassObject = {
    "twik-variant-popup-container": twikVariantPopupContainer,
    "twik-variant-actual-popup": twikVariantActualPopup,
    "twik-modal": twikModal,
    "twik-variant-title": twikVariantTitle,
    "twik-variant-select-field": twikVariantSelectField,
    "twik-variant-icon": twikVariantIcon,
    "twik-variant-p": twikVariantP,
    "twik-variant-error-popup-container": twikVariantErrorPopupContainer,
    "twik-variant-popup-close": twikVariantPopupClose,
    "twik-variant-paragraph-margin": twikVariantParagraphMargin
};


// ************************
// Auxiliary functions:
// ************************
function getTheSelectorElement() {
    // return document.getElementById('mce-EMAIL');

    var desiredSelector;

    if (twik_tags != null) {
        for (var twik_tag of twik_tags) {
          if (document.querySelector(twik_tag.selector) && twik_tag.value) {
            desiredSelector = twik_tag.selector;
          }
        }
      }
        
      var desiredElement = document.querySelector(desiredSelector);

      return desiredElement;
}

function validateInput(e) {
    if (e.target.value === correctInput) {
        changeElementVisibilityTo(validationOptionsModalId, 'block');
        changeElementVisibilityTo(validationOptionsContainerId, 'flex');
    }
}

function changeElementVisibilityTo(elementId, displayStyle) {
    let element = document.getElementById(elementId);
    element.style.display = displayStyle;

    if (displayStyle !== 'none') {
        element.style.zIndex = "99";
    }
}

function onChangeValidationOption(e, couponInput) {
    // If an incorrect validation option is chosen, clear the coupon-input and present an error message
    if (validationComponentType === "select") {
        // Hide the validation dropdown
        changeElementVisibilityTo(validationOptionsContainerId, 'none');
        changeElementVisibilityTo(validationOptionsModalId, 'none');
        
        if (!selectValidationOptions.get(e.target.value)) {
            couponInput.value = '';
    
            changeElementVisibilityTo(validationErrorContainerId, 'flex');
        }
    
        // bring the 'select' to have the placeholder option selected
        document.getElementById(validationOptionsSelectId).selectedIndex = "0";
    }
    else if (validationComponentType === "input") {
        if (e.target.value === correctValidationValue) {
            changeElementVisibilityTo(validationOptionsContainerId, 'none');
            changeElementVisibilityTo(validationOptionsModalId, 'none');
            e.target.value = '';
        }
    }
}

function insertAfter(referenceNode, newNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}

function createElementWithStyle(elementType, styleObject, text = null) {
    let element = document.createElement(elementType);

    if (styleObject) {
        for (let key in styleObject) {
            element.style[key] = styleObject[key];
        }
    }

    if (text) {
        element.innerHTML = text;
    }

    return element;
}

function createValidationSelect(couponInput) {
    // Create the select list element
    let selectList = createElementWithStyle('select', classNameToClassObject['twik-variant-select-field']);
    selectList.classList.add("w-select");

    selectList.id = validationOptionsSelectId;
    selectList.name = validationOptionsSelectId;

    // Create and append the select options
    for (const [key, value] of selectValidationOptions.entries()) {
        let option = document.createElement("option");
        option.value = key;
        option.text = key;
        selectList.appendChild(option);
    }

    // Create the event when selecting an option
    selectList.addEventListener('change', function(e) { onChangeValidationOption(e, couponInput); }, false);

    return selectList;
}

function createValidationInput(couponInput) {
    // Create the select list element
    let validationInput = createElementWithStyle('input', classNameToClassObject['twik-variant-select-field']);
    validationInput.classList.add("w-input");

    validationInput.id = validationOptionsSelectId;
    validationInput.name = validationOptionsSelectId;

    // Create the event when selecting an option
    validationInput.addEventListener('keyup', function(e) { onChangeValidationOption(e, couponInput); }, false);
    return validationInput;
}

function createValidationObject(couponInput) {
    if (validationComponentType === "select") {
        return createValidationSelect(couponInput);
    }
    else if (validationComponentType === "input") {
        return createValidationInput(couponInput);
    }
}

function closeModal(e, divModal) {
    if (e.target === divModal) {
        divModal.style.display = "none";
    }
}

function createModalDivAndAppendChild(modalChild) {
    let divModal = createElementWithStyle('div', classNameToClassObject['twik-modal']);
    divModal.id = validationOptionsModalId;
    divModal.appendChild(modalChild);

    // When the user clicks anywhere outside of the modal, close it
    window.addEventListener("click", function(e) { closeModal(e, divModal); }, false);

    return divModal;
}

function createCouponValidationObject(couponInput) {
    // Create the validation object for the coupon
    let validationObject = createValidationObject(couponInput);

    // Create the containig form and append validationObject
    let selectForm = createElementWithStyle('form', classNameToClassObject['twik-variant-select-field']);
    selectForm.id = validationOptionsSelectFormId;
    selectForm.name = validationOptionsSelectFormId;
    selectForm.appendChild(validationObject);

    // Create the div containing the form and append it
    let divSelectForm = createElementWithStyle('div', classNameToClassObject['twik-variant-select-field']);
    divSelectForm.classList.add("w-form");
    divSelectForm.appendChild(selectForm);

    // create the paragraph and title
    let p = createElementWithStyle('p', classNameToClassObject['twik-variant-p'], "כדי להשתמש בקופון זה עליך לבחור ב-4 הספרות הראשונות של הכרטיס");
    let h3 = createElementWithStyle('h3', classNameToClassObject['twik-variant-title'], "מהו סוג כרטיס האשראי שברשותך?");

    // Create the variant icon
    let img = document.createElement("img");
    img.alt = "";
    img.src = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTEyLjAwMSA1MTIuMDAxIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTIuMDAxIDUxMi4wMDE7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxwYXRoIHN0eWxlPSJmaWxsOiMxNDZBQTg7IiBkPSJNNDgxLjUzLDM0Ny4wMzNsMzAuMDE1LTE5MS42NDljMy4xMjEtMTkuNDQ4LTEwLjExMi0zNy43NDctMjkuNTYxLTQwLjg3N2wwLDBMNzYuOTczLDQ5LjUwMQ0KCUM1Ny41MjUsNDYuMzgsMzkuMjI3LDU5LjYxMywzNi4xMDYsNzkuMDYxbC0xNC4zOTIsODkuNjI3djE3Ny4yM0w0ODEuNTMsMzQ3LjAzM3oiLz4NCjxwYXRoIHN0eWxlPSJmaWxsOiMxMjYwOTk7IiBkPSJNNDgxLjk4NSwxMTQuNTA3TDM2Ni45NTMsOTYuMDQ5QzI4OS42OTQsMjE0LjI2NCwxNjQuNzk5LDI5Ni4xNDIsNjkuMDE5LDM0Ni4wMzRsNDEyLjUxMSwwLjk5OQ0KCWwzMC4wMTUtMTkxLjY0OUM1MTQuNjY2LDEzNS45MzUsNTAxLjQzMywxMTcuNjM3LDQ4MS45ODUsMTE0LjUwN0w0ODEuOTg1LDExNC41MDd6Ii8+DQo8cGF0aCBzdHlsZT0iZmlsbDojNDM5OEQxOyIgZD0iTTM1LjY2OSwxNTkuNzcxaDQxMC4xOTJjMTkuNjk4LDAsMzUuNjY5LDE1Ljk3MSwzNS42NjksMzUuNjY5djIzMS44NDgNCgljMCwxOS42OTgtMTUuOTcxLDM1LjY2OS0zNS42NjksMzUuNjY5SDM1LjY2OUMxNS45NzEsNDYyLjk1NiwwLDQ0Ni45ODYsMCw0MjcuMjg4VjE5NS40NEMwLDE3NS43NDIsMTUuOTcxLDE1OS43NzEsMzUuNjY5LDE1OS43NzF6DQoJIi8+DQo8cGF0aCBzdHlsZT0iZmlsbDojM0U4Q0M3OyIgZD0iTTQ0NS44NjEsMTU5Ljc3MWgtNy4xMzRjLTg0LjE3OSwxNDkuNDQ0LTI0MS40NjksMjUxLjk1Ni0zMzcuNDksMzAzLjE4NWgzNDQuNjI0DQoJYzE5LjY5OCwwLDM1LjY2OS0xNS45NzEsMzUuNjY5LTM1LjY2OVYxOTUuNDRDNDgxLjUzLDE3NS43NDIsNDY1LjU1OSwxNTkuNzcxLDQ0NS44NjEsMTU5Ljc3MXoiLz4NCjxyZWN0IHg9IjQ0LjU4NiIgeT0iMjA0LjM1NyIgc3R5bGU9ImZpbGw6I0ZEQjYyRjsiIHdpZHRoPSI4OS4xNzIiIGhlaWdodD0iNzEuMzM4Ii8+DQo8Zz4NCgk8cmVjdCB4PSI0NC41ODYiIHk9IjIzMS4xMDkiIHN0eWxlPSJmaWxsOiNGRDdCMkY7IiB3aWR0aD0iMjYuNzUyIiBoZWlnaHQ9IjE3LjgzNCIvPg0KCTxyZWN0IHg9IjEwNy4wMDciIHk9IjIzMS4xMDkiIHN0eWxlPSJmaWxsOiNGRDdCMkY7IiB3aWR0aD0iMjYuNzUyIiBoZWlnaHQ9IjE3LjgzNCIvPg0KPC9nPg0KPGNpcmNsZSBzdHlsZT0iZmlsbDojRkRCNjJGOyIgY3g9IjM5Mi4zNTgiIGN5PSIzNzMuNzg0IiByPSI0NC41ODYiLz4NCjxjaXJjbGUgc3R5bGU9ImZpbGw6I0RFNEMzQzsiIGN4PSIzMzguODU0IiBjeT0iMzczLjc4NCIgcj0iNDQuNTg2Ii8+DQo8Zz4NCgk8cmVjdCB4PSIzNS42NjkiIHk9IjMzOC4xMTUiIHN0eWxlPSJmaWxsOiM4N0NFRDk7IiB3aWR0aD0iNTMuNTAzIiBoZWlnaHQ9IjE3LjgzNCIvPg0KCTxyZWN0IHg9IjEyNC44NDEiIHk9IjMzOC4xMTUiIHN0eWxlPSJmaWxsOiM4N0NFRDk7IiB3aWR0aD0iNTMuNTAzIiBoZWlnaHQ9IjE3LjgzNCIvPg0KCTxyZWN0IHg9IjIxNC4wMTMiIHk9IjMzOC4xMTUiIHN0eWxlPSJmaWxsOiM4N0NFRDk7IiB3aWR0aD0iNTMuNTAzIiBoZWlnaHQ9IjE3LjgzNCIvPg0KCTxyZWN0IHg9IjM1LjY2OSIgeT0iMzkxLjYxOSIgc3R5bGU9ImZpbGw6Izg3Q0VEOTsiIHdpZHRoPSIyMzEuODQ4IiBoZWlnaHQ9IjE3LjgzNCIvPg0KCTxyZWN0IHg9IjMxMi4xMDMiIHk9IjIwNC4zNTciIHN0eWxlPSJmaWxsOiM4N0NFRDk7IiB3aWR0aD0iMTcuODM0IiBoZWlnaHQ9IjM1LjY2OSIvPg0KCTxyZWN0IHg9IjM0Ny43NzIiIHk9IjIwNC4zNTciIHN0eWxlPSJmaWxsOiM4N0NFRDk7IiB3aWR0aD0iMTcuODM0IiBoZWlnaHQ9IjM1LjY2OSIvPg0KCTxyZWN0IHg9IjM4My40NCIgeT0iMjA0LjM1NyIgc3R5bGU9ImZpbGw6Izg3Q0VEOTsiIHdpZHRoPSIxNy44MzQiIGhlaWdodD0iMzUuNjY5Ii8+DQoJPHJlY3QgeD0iNDE5LjEwOSIgeT0iMjA0LjM1NyIgc3R5bGU9ImZpbGw6Izg3Q0VEOTsiIHdpZHRoPSIxNy44MzQiIGhlaWdodD0iMzUuNjY5Ii8+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==";

    // Create the div containing the img and append it
    let divIcon = createElementWithStyle('div', classNameToClassObject['twik-variant-icon']);
    divIcon.appendChild(img);

    // Create the popup div and append all the above elements into it
    let divPopup = createElementWithStyle('div', classNameToClassObject['twik-variant-actual-popup']);
    divPopup.appendChild(divIcon);
    divPopup.appendChild(h3);
    divPopup.appendChild(p);
    divPopup.appendChild(divSelectForm);

    // Create the container div and append divPopup into it
    let divPopupContainer = createElementWithStyle('div', classNameToClassObject['twik-variant-popup-container']);
    divPopupContainer.id = validationOptionsContainerId;
    divPopupContainer.appendChild(divPopup);

    // Create the modal div
    divModal = createModalDivAndAppendChild(divPopupContainer);

    // Append the coupon-input dropdown right after the couponInput element
    insertAfter(couponInput, divModal);
}

function createCouponValidationErrorMessage(couponInput) {
    // create the close-button
    let closeButton = createElementWithStyle('button', null, "סגור");
    closeButton.classList.add("btn");
    closeButton.classList.add("button");
    closeButton.addEventListener('click', function() {
            changeElementVisibilityTo(validationErrorContainerId, 'none');
            changeElementVisibilityTo(validationOptionsModalId, 'none'); 
        }, false);

    // create the paragraph and title
    let p = createElementWithStyle('p', classNameToClassObject['twik-variant-paragraph-margin'], "כרטיס האשראי שהזנת לא מתאים לקוד הקופון. לכן הוא נמחק");
    let h3 = createElementWithStyle('h3', null, "לא ניתן להשתמש בקוד הקופון שהזנת");

    // Create the popup div and append all the above elements into it
    let errorDivPopup = createElementWithStyle('div', classNameToClassObject['twik-variant-actual-popup']);
    errorDivPopup.appendChild(h3);
    errorDivPopup.appendChild(p);
    errorDivPopup.appendChild(closeButton);

    // Create the container div and append divPopup into it
    let errorDivPopupContainer = createElementWithStyle('div', classNameToClassObject['twik-variant-error-popup-container']);
    errorDivPopupContainer.id = validationErrorContainerId;
    errorDivPopupContainer.appendChild(errorDivPopup);
    
    // Append the errorDivPopupContainer to document.body
    // document.body.appendChild(errorDivPopupContainer);
    insertAfter(couponInput, errorDivPopupContainer);
}

function runCoupnValidationCode() {
    // Get the coupon input element
    var couponInput = getTheSelectorElement();

    // When the document loads, add the coupon-input validation select-dropdown.
    // Notice that this dropdown is not visible and will only become visible if the user types
    // the correct coupon code.
    createCouponValidationObject(couponInput);

    // Create the error message that appears when the user enters a wrong coupon validation code,
    // and append it to document.body
    createCouponValidationErrorMessage(couponInput);

    // Add the wanted behavior to the coupon input element
    couponInput.addEventListener("keyup", function(e) { validateInput(e); }, false);
}

// ************************
// The code execution part:
// ************************
// window.addEventListener("load", runCoupnValidationCode, false);
runCoupnValidationCode();