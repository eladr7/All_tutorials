function disableAutoScroll() {
	if (window.jQuery) {  
        $("html, body").stop();
    }
	
    window.scrollBy({
		top: 0,
		behavior: 'smooth'
	});
}

// ************************
// The code execution part:
// ************************
window.addEventListener("load", disableAutoScroll, false);
// disableAutoScroll();