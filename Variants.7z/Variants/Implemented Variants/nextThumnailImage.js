const thumbnailsContainerRegex = "[tT](humbnails).*(container)+";
const thumbnailsNextButtonRegex = "[rR](ight)|[nN](ext|xt)";

// runTheNextThumbnail();
// If your site doesn't have the jquery script, comment out the line above: runTheNextThumbnail();
// and uncomment this line below (i.e. loadJqueryAndThenRunTheNextThumbnail();)
// *And vice-versa
loadJqueryAndThenRunTheNextThumbnail();
var $;
function runTheNextThumbnail() {
    $ = jQuery.noConflict();
    $(document).ready(function () {
        setTimeout(function () {
            pressTheNextThumbnailButton();
        }, 1);
    });
}

function loadJqueryAndThenRunTheNextThumbnail() {
    function loadScript(url, callback) {
        var script = document.createElement("script")
        script.type = "text/javascript";

        if (script.readyState) { //IE
            script.onreadystatechange = function () {
                if (script.readyState == "loaded" || script.readyState == "complete") {
                    script.onreadystatechange = null;
                    callback();
                }
            };
        } else { //Others
            script.onload = function () {
                callback();
            };
        }

        script.src = url;
        document.getElementsByTagName("head")[0].appendChild(script);
    }

    loadScript("https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js", function () {
        //jQuery loaded
        runTheNextThumbnail();
    });
}

function pressTheNextThumbnailButton() {
	const $nextThumbnailButton = getNextThumbnailButton();

	$nextThumbnailButton.click();
}

function getNextThumbnailButton() {
	const $container = getElementWithAttrMatchingRegex('body', '*', thumbnailsContainerRegex);

	return getElementWithAttrMatchingRegex($container, 'button', thumbnailsNextButtonRegex);
}

function getElementWithAttrMatchingRegex(contextElement, elementType, regex) {
	let result = undefined;

	// go over all the elements inside body, and in each - check if there
	// is an attribute value that matches the regex; if so - return it
	$(contextElement).find(elementType).filter(function () {
		if ($(this)[0].attributes) {
			$.each($(this)[0].attributes, function() {
				if(this.specified) {
					let attributeValue = this.value;
					var regexObj = new RegExp(regex);
					if (attributeValue && attributeValue.match(regexObj)) {
						result = $(this)[0].ownerElement;
						return false; // breaks
					}
				}
			});
		}

		if (result) {
			return false;
		}
	});

    return result;
}
