// Set scrollY to 'true' in order to get a vertical scroller
var scrollY = true;

// Set scrollX to 'true' in order to get a horizontal scroller
var scrollX = true;


function getItemToScroll() {
	// return document.getElementsByClassName('swiper-container-vertical')[0];
	var desiredSelector;

	if (twik_tags != null) {
		for (let i = 0; i < twik_tags.length; i++) {
			if (document.querySelector(twik_tags[i].selector) && twik_tags[i].name.includes('-add-scrl')) {
				desiredSelector = twik_tags[i].selector;
			}
		}
	  }

	  var desiredElement = document.querySelectorAll(desiredSelector);
	  return desiredElement;
}

function addScroller() {
	var itemToScroll = getItemToScroll();

	if (scrollY) {
		itemToScroll.style.overflowY = 'scroll';
		// itemToScroll.setAttribute( 'style', 'overflow-y: scroll !important' );
	}
	if (scrollX) {
		itemToScroll.style.overflowX = 'scroll';
		// itemToScroll.setAttribute( 'style', 'overflow-x: scroll !important' );
	}
}

// ************************
// The code execution part:
// ************************
window.addEventListener("load", addScroller, false);
// addScroller();
