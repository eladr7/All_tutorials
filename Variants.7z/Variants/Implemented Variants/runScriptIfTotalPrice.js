// ****************************************************************
// Choose the conditions that will determine if the script will run
// ****************************************************************
// Choose the price threshold to run the script
var priceThreshold = 200;

// If true - the script will run if the total price equals or greater than priceThreshold;
// If false- the script will run if the total price equals or smaller than priceThreshold;
var runIfTotalPriceIsLargerThanThreshold = true;

// Put in this function the script you want to run if the conditions above are met
function runCustomizableScript() {
	console.log("Hello World!!");
}

// ********************
// Auxiliary functions:
// ********************
function getTotalPriceElemnt() {
	// return document.querySelectorAll('[data-raofz="16"]')[15];
	var desiredSelector;

	if (twik_tags != null) {
		for (let i = 0; i < twik_tags.length; i++) {
			if (document.querySelector(twik_tags[i].selector) && twik_tags[i].name.includes('-tot-cost')) {
				desiredSelector = twik_tags[i].selector;
			}
		}
	}

	var desiredElement = document.querySelectorAll(desiredSelector);

	return desiredElement;
}

function getTotalPrice(totalPriceElement) {
	switch (totalPriceElement.nodeName) {
		case "SPAN":
		case "DIV":
		case "P":
		case "P":
		case "LI":
			return parseFloat(totalPriceElement.innerHTML);
		case "INPUT":
			return parseFloat(totalPriceElement.value);
		default:
			return 0;
	}

	return 0;
}

function runTotalPriceScript() {
	const totalPriceElement = getTotalPriceElemnt();
	const totalPrice = getTotalPrice(totalPriceElement);

	if (runIfTotalPriceIsLargerThanThreshold) {
		// The script should run if the total price is larger than the determined threshold

		// Run the script if indeed the total price is larger than the threshold
		if (totalPrice >= priceThreshold) {
			runCustomizableScript();
		}
	} else {
		// The script should run if the total price is smaller than the determined threshold

		// Run the script if indeed the total price is smaller than the threshold
		if (totalPrice <= priceThreshold) {
			runCustomizableScript();
		}
	}
}

// ************************
// The code execution part:
// ************************
window.addEventListener("load", runTotalPriceScript, false);
// runTotalPriceScript();
