const currencies = ["$", "€", "₪", "£"];

const currenciesDataObj = {
		'America': ['USD', '$'], // US Dollar
		'Europe': ['EUR', '€'], // Euro
		'Israel': ['ILS', '₪'], // Israeli New Sheqel
		'England': ['GBP', '£'] // British Pound Sterling
		// 'CRC': '₡', // Costa Rican Colón
		// 'INR': '₹', // Indian Rupee
		// 'JPY': '¥', // Japanese Yen
		// 'KRW': '₩', // South Korean Won
		// 'NGN': '₦', // Nigerian Naira
		// 'PHP': '₱', // Philippine Peso
		// 'PLN': 'zł', // Polish Zloty
		// 'PYG': '₲', // Paraguayan Guarani
		// 'THB': '฿', // Thai Baht
		// 'UAH': '₴', // Ukrainian Hryvnia
		// 'VND': '₫', // Vietnamese Dong
	};

var rate = null;

function convertEachMoneyValueToItsValueInTheCurrentCountry(currentCountryCurrencyData) {
	// Match every digit with a currency symbol
	document.body.innerHTML = document.body.innerHTML.replace(/((\d|,|\.)+(\$|€|₪|£))|((\$|€|₪|£)(\d|,|\.)+)/g, async function (match) {
		// Get the number part
		let number = parseFloat(match.replace(/\$|€|₪|£|,/g, ""));

		// If the currency symbol is one of the supported currencies; replace the currency
		// symbol with the currency symbol of the country the user is currently at, and also
		// convert the value to the correct one
		if (currencies.includes(match.charAt(0))) {
			if (!rate) {
				await getExchangeRate(currentCountryCurrencyData[0], match.charAt(0));
			}
			// The currency symbol comes before the number
			return currentCountryCurrencyData[1] + parseInt(number * rate);
		}
		else {
			if (!rate) {
				await getExchangeRate(currentCountryCurrencyData[0], match.charAt(match.length - 1));
			}

			// The currency symbol comes after the number
			return parseInt(number * rate) + currentCountryCurrencyData[1];
		}
	});
}

function handleMoneyValuesNotInTheSameElement(currentCountryCurrencyData) {
	let currencyElems = [...document.querySelectorAll("*")].filter(value => currencies.includes(value.innerHTML));
	currencyElems.map(async (value) => {
		let symbol = value.innerText;
		let numberChild;
		let number;

		let children = [...value.parentElement.childNodes];
		for (let i = 0; i < children.length; i++) {
			// if (children[i].nodeType === 3 && children[i].nodeValue.value.match(/^[0-9]+$/)) {
			if (children[i].nodeType === 3) {
				numberChild = children[i];
				number = parseFloat(children[i].nodeValue.replace(",", ""));
				break;
			}
		}

		if (!rate) {
			await getExchangeRate(currentCountryCurrencyData[0], symbol);
		}

		numberChild.nodeValue = parseInt(number * rate);
		value.innerText = currentCountryCurrencyData[1];
	});
}

function getCurrencyData(continentName, countryName) {
	switch (continentName) {
		case 'America':
			return currenciesDataObj[continentName];
		case 'Europe':
			if (countryName === 'England' || countryName === "Scotland") {
				return currenciesDataObj['England'];
			} else {
				return currenciesDataObj['Europe'];
			}
		default:
			if (countryName === 'Israel') {
				return currenciesDataObj[countryName];
			} else {
				return null;
			}
	}
}

function get(json) {
	var rate = json['rate'];
}

function jsonp(uri) {
	return new Promise(function (resolve, reject) {
		// var id = '_' + Math.round(10000 * Math.random());
		var callbackName = 'parseExchangeRate';
		window[callbackName] = function (data) {
			delete window[callbackName];
			var ele = document.getElementById(id);
			ele.parentNode.removeChild(ele);
			resolve(data);
		}

		var script = document.createElement('script');
		// script.src = uri + '&callback=' + callbackName;
		script.src = uri + "&dataType:'json'";
		// script.addEventListener('load', parseExchangeRate, false);
		script.addEventListener('error', reject);
		script.addEventListener('load', async function() { await parseExchangeRate(); }, false);
		(document.getElementsByTagName('head')[0] || document.body || document.documentElement).appendChild(script);
		// document.body.appendChild(script);

		// var src = uri + '&callback=' + callbackName;
		// var script = document.createElement('script');
		// script.src = src;
		// script.id = id;
		// script.addEventListener('error', reject);
		// (document.getElementsByTagName('head')[0] || document.body || document.documentElement).appendChild(script);
	});
}

async function getRate(from, to) {
	// http://query.yahooapis.com/v1/public/yql?q=select%20rate%2Cname%20from%20csv%20where%20url%3D'http%3A%2F%2Fdownload.finance.yahoo.com%2Fd%2Fquotes%3Fs%3D"+from+to+"%253DX%26f%3Dl1n'%20and%20columns%3D'rate%2Cname'&format=json&callback=parseExchangeRate
	// "http://query.yahooapis.com/v1/public/yql?q=select%20rate%2Cname%20from%20csv%20where%20url%3D'http%3A%2F%2Fdownload.finance.yahoo.com%2Fd%2Fquotes%3Fs%3D"+from+to+"%253DX%26f%3Dl1n'%20and%20columns%3D'rate%2Cname'&format=json&callback=parseExchangeRate"
	  // Get google autocomplete results.
	// await jsonp("http://query.yahooapis.com/v1/public/yql?q=select%20rate%2Cname%20from%20csv%20where%20url%3D'http%3A%2F%2Fdownload.finance.yahoo.com%2Fd%2Fquotes%3Fs%3D"+from+to+"%253DX%26f%3Dl1n'%20and%20columns%3D'rate%2Cname'&format=json")
	//           https://api.exchangeratesapi.io/latest?symbols=USD,GBP
	await jsonp("https://api.exchangeratesapi.io/latest?symbols=" + from + "," + to)
		// .then(res => res[1])
		.then(res => {
			var name = res.query.results.row.name;
			rate = parseFloat(res.query.results.row.rate, 10);
		})
		// If error, don't display list.
		.catch((errorMsg) => { 
			let suka = "blat";
			suka = errorMsg;
		});
}

function parseExchangeRate(data) {
	var name = data.query.results.row.name;
	rate = parseFloat(data.query.results.row.rate, 10);
	// alert("Exchange rate " + name + " is " + rate);
}

function getExchangeRate(currentCountryCurrencyName, symbol) {
	if(!currencies.includes(symbol)) return;

	let fromCurrency = '';
	if (symbol === "€") {
		fromCurrency = 'EUR';
	}
	else if (symbol === "$") {
		fromCurrency = 'USD';
	}
	else if (symbol === "£") {
		fromCurrency = 'GBP';
	}
	else if (symbol === "₪") {
		fromCurrency = 'ILS';
	}

	getRate(fromCurrency, currentCountryCurrencyName);
}

const onSuccess = function (geoipResponse) {
	let continentName = geoipResponse.continent.names.en;
	let countryName = geoipResponse.country.names.en;
	
	let currentCountryCurrencyData = getCurrencyData(continentName, countryName);
	if (!currentCountryCurrencyData) {
		return;
	}

	convertEachMoneyValueToItsValueInTheCurrentCountry(currentCountryCurrencyData);
	// handleMoneyValuesNotInTheSameElement(currentCountryCurrencyData);
};

const onError = function (error) {
	window.console.log("something went wrong: " + error.error)
};

const getGeoIp2 = function () {
	geoip2.city(onSuccess, onError);
}

const onLoad = function () {
	let src = "//js.maxmind.com/js/apis/geoip2/v2.1/geoip2.js";
	let script = document.createElement('script');
	script.src = src;
	script.async = 'true';
	script.addEventListener('load', getGeoIp2);
	(document.getElementsByTagName('head')[0] || document.body || document.documentElement).appendChild(script);
}

// Run the lookup when the document is loaded and parsed. You could
// also use something like $(document).ready(onLoad) if you use jQuery.
document.addEventListener('DOMContentLoaded', onLoad);
// onLoad();