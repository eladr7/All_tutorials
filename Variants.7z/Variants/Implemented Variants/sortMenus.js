// ************************
// Adjustable options:
// ************************
var keyWordsToSortBy = ["בורגס"];
// var keyWordsToSortBy = ["טבריה", "new-york", "haifa"];

// keywordsLength is the total number of characters in keyWordsToSortBy.
// e.g. If keyWordsToSortBy = ["aaa", "bb"], keywordsLength will get the value 5
var keywordsLength = getArrayCharsCount(keyWordsToSortBy);

// The name of the class each menu-to-sort should have in its class list.
// Note that we assume here that each menu has this class in its class list.
var menusClassName = '.mega-menu--col';

// The type of container whithin each menu
var submenuContainerType = 'ul';


// ************************
// The code execution part:
// ************************
window.addEventListener("load", function() { sortMenusAccordingtoKeywords(keyWordsToSortBy); });
// sortMenusAccordingtoKeywords(keyWordsToSortBy);

function sortMenusAccordingtoKeywords(keyWordsToSortBy) {
	// Get the menu item to sort
	let menusToSort = getElementToSort();

	for (let menu of menusToSort) {
		// Sort the items inside menu according to the density of keyWordsToSortBy in each sub-element
		// of menu
		sortMenu(menu, keyWordsToSortBy);
	}
}

function getArrayCharsCount(stringsArray) {
	let totalLength = 0;
	
	for (let stringItem of stringsArray) {
		totalLength += stringItem.length;
	}

	return totalLength;
}

function getElementToSort() {
	let menusToSort = [];

	//Gets list element.
	if (twik_tags != null) {
		for (let item of twik_tags) {
			let querySelector = document.querySelector(item.selector);
			if (querySelector && item.name.includes('sort')) {
				menusToSort.push(querySelector);
			}
		}
	}

	return menusToSort;
}

function sortMenu(menu, keyWordsToSortBy) {
	let menuItemsDensityArray = [];

	// Sub item sort
	// Go over each menuItem inside menu, and for each, 
	let menuItems = menu.querySelectorAll(menusClassName);
	for (let item of menuItems) {
		// listItemsDensityArray will contain object pairs of each list-item and its
		// keyWordsToSortBy density.
		// e.g. [{value: li1, density: 5}, {value: li2, density: 2}, {value: li3, density: 8}]
		let listItemsDensityArray = getListItemsDensities(item, keyWordsToSortBy)

		// Re-arrange the list-items according to their densities order.
		// Also get the total density of this item
		let totalItemDensity = sortListItemsAccordingToDensity(listItemsDensityArray);

		// Add this item to the array of menuItems.
		// This array structure is as follows: 
		// [{tag: menuItem1, density: 20}, {tag: menuItem2, density: 31}, {tag: menuItem3, density: 15}]
		let tag = item;
		menuItemsDensityArray.push({
			tag: tag,
			density: totalItemDensity
		});
	}

	// Sort the array of {menu-item, density} pairs, according to the densities
	menuItemsDensityArray.sort((a, b) => b.density - a.density);

	// Re-arrange the menu items according to their densities order.
	for (let _item of menuItemsDensityArray) {
		_item.tag.parentNode.appendChild(_item.tag);
	}
}

function sortListItemsAccordingToDensity(listItemsDensityArray) {
	let totalItemDensity = 0;

	// Sort the array of {list-item, density} pairs, according to the densities
	let sortedElements = listItemsDensityArray;
	sortedElements.sort((a, b) => b.density - a.density); // Sort by density

	// Re-arrange the list-items according to their densities order.
	// Also get the total density of this item
	for (let _item of sortedElements) {
		totalItemDensity += _item.density;
		_item.value.parentNode.appendChild(_item.value); 
	}

	return totalItemDensity;
}

// listItemsDensityArray will contain object pairs of each list-item and its keyWordsToSortBy density.
// e.g. [{value: someLi, density: 5}, {value: someLi, density: 2}, {value: someLi, density: 8}]
function getListItemsDensities(item, keyWordsToSortBy) {
	// Buffer for storing tag and density
	let listItemsDensityArray = [];

	// Sort target, the submenu item lists
	let listElement = item.querySelector(submenuContainerType);
	for (let child of listElement.children) {
		if (child.innerHTML.length <= 0) {
			continue;
		}

		let keywordsCount = count(child.innerHTML, keyWordsToSortBy);
		let density = (keywordsLength * keywordsCount * 100) / child.innerHTML.length;
		listItemsDensityArray.push({
			value: child,
			density: density,
		});
	}

	return listItemsDensityArray;
}

//let menu = document.querySelector('.menu-nav--item.has-mega-menu.nav-item:nth-child(5)'); // Menu
function count(main_str, sub_str) {
	let appearancesCount = 0;
	
	// Makes sure main_str is a string
	main_str += '';
	for (let keyWord of sub_str) {
		// Makes sure keyWordis a string
		keyWord += '';
		let subStr = keyWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
		appearancesCount += (main_str.match(new RegExp('[^a-z]' + subStr + '[^a-z]', 'gi')) || []).length;
	}

	return appearancesCount;
}
