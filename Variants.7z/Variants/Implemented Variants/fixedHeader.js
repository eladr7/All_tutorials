function fixateHeader() {
    var header = document.getElementsByTagName("HEADER")[0];

    header.style.position = 'fixed';
    header.style.zIndex = 9;
    header.style.opacity = 0.8;
    header.style.width = '100%';
}

// ************************
// The code execution part:
// ************************
// window.addEventListener("load", fixateHeader, false);
fixateHeader();
