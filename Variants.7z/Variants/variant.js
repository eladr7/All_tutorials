// Edge cases to check:
// 1. All zeros:            int[] A = {0, 0, 0, 0, 0};
// 2. One negative:         int[] A = {4, 1, -8, 9, 6};
//                          int[] A = {-4, 1, 8, 9, 6};
// 3. Two negatives:        int[] A = {-2, 1, -2, 9, 6};
//                          int[] A = {-4, 1, -8, 9, 60};
// 4. Three negatives:      int[] A = {-4, -1, -8, 9, 6};
// 5. Three total items:    int[] A = {-4, 1, -8};
// 5.                       int[] A = {-4, 1,  8};
// 5.                       int[] A = {-4, -1, 8};
// 6. All zeros except one: int[] A = {0, 1, 0, 0, 0};
// 7. All zeros except two: int[] A = {-4, 1, 0, 0, 0};

int[] A = {-4, 1, -8, 9, 6};

// ***********************************
// # Get the three positive maximums #
// ***********************************
int maxPositive1 = maxPositive2 = maxPositive3 = 0;
int maxPositive1Index, maxPositive2Index;

for (int i = 0; i < A.length; i++)
{
	if (A[i] > maxPositive1)
	{
		maxPositive1 = A[i];
		maxPositive1Index = i;
	}
}

for (int i = 0; i < A.length; i++)
{
	if (A[i] == maxPositive1 && i == maxPositive1Index) continue;

	if (A[i] > maxPositive2)
	{
		maxPositive2 = A[i];
		maxPositive2Index = i;
	}
}

for (int i = 0; i < A.length; i++)
{
	if (A[i] == maxPositive1 && i == maxPositive1Index || A[i] == maxPositive2 && i == maxPositive2Index) continue;

	if (A[i] > maxPositive3)
	{
		maxPositive3 = A[i];
	}
}


// **********************************
// # Get the two negatives minimums #
// **********************************

// minNegative1 will be the smallest negative number in the array.
// minNegative2 will be larger than (or equal to) minNegative1.
// e.g. minNegative1 will be -5 and minNegative2 will be -3.
int minNegative1 = minNegative2 = 0;
int minNegative1Index

for (int i = 0; i < A.length; i++)
{
	if (A[i] < minNegative1)
	{
		minNegative1 = A[i];
		minNegative1Index = i;
	}
}

for (int i = 0; i < A.length; i++)
{
	if (A[i] == minNegative1 && i == minNegative1Index) continue;

	if (A[i] < minNegative2)
	{
		minNegative2 = A[i];
	}
}


// ****************************************************************
// # Calculate the multiplications of the three positive maximus  #
// # and also the multiplication of the maximum positive with the #
// # two minimum negatives                                        #
// ****************************************************************
int positivesMultiplication = maxPositive1 * maxPositive2 * maxPositive3;
int positiveAndNegativesMultiplication = maxPositive1 * minNegative1 * minNegative2;

if (positivesMultiplication > positiveAndNegativesMultiplication)
{
	System.out.println(maxPositive1);
	System.out.println(maxPositive2);
	System.out.println(maxPositive3);
	return positivesMultiplication;
}
else if (positiveAndNegativesMultiplication > 0)
{
	System.out.println(maxPositive1);
	System.out.println(minNegative1);
	System.out.println(minNegative2);
	return positiveAndNegativesMultiplication;
}
else
{
	System.out.println("There is no positive multiplication of 3 numbers in the array");
	return 0;
}