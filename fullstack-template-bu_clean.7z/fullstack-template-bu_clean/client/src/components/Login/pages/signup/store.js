import form from '../../organism/signup.form';

class Store {
  form = form;
}

export default Store;
