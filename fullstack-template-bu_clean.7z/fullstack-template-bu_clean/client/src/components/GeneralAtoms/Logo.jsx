import React from 'react';

const Logo = () => <div className="logo">Burger Time</div>;

export default Logo;
