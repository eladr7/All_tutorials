const Genres = ["Comedy", "Drama", "Fantasy"];

export default Genres;
