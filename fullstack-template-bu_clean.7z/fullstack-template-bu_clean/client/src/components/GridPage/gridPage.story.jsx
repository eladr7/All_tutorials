import React from 'react';

import { storiesOf } from '@storybook/react';

import GridPage from './GridPage';

storiesOf('GridPage', module)
  .add('GridPage', () => (
    <GridPage
    />
  ));
