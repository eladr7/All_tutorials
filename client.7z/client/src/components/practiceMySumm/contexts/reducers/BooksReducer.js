// import React from 'react';
import { v4 as uuidv4} from 'uuid';
export const BOOKS_OPS = {
    ADD_BOOK: "ADD_BOOK",
    REMOVE_BOOK: "REMOVE_BOOK"
}

export const BooksReducer = (state, action) => {
    switch(action.type)
    {
        case BOOKS_OPS.ADD_BOOK:
            return [
                ...state,
                {
                    name: action.book.name,
                    author: action.book.author,
                    id: uuidv4() 
                }
            ];
        case BOOKS_OPS.REMOVE_BOOK:
            return state.filter(book => book.id != action.book.id);
        default:
            return state;
    }
}