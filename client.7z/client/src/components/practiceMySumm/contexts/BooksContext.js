import React, { createContext, useReducer, useEffect } from 'react';
import {BooksReducer} from './reducers/BooksReducer';

export const BooksContext = createContext();
const BooksContextProvider = (props) => {
    const [books, dispatch] = useReducer(BooksReducer, [], () => {
        const booksFromLocalStorage = localStorage.getItem('books');
        return booksFromLocalStorage ? JSON.parse(booksFromLocalStorage) : [];
        // If there are - put them into books. otherwise return []
    });

    useEffect(
        () => { localStorage.setItem('books', JSON.stringify(books)); },
        [books]
    );

    return (
        <BooksContext.Provider value={{ books, dispatch }}>
            {props.children}
        </BooksContext.Provider>
    );
}

export default BooksContextProvider;