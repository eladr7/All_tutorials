import React from 'react';
import BooksContextProvider from './contexts/BooksContext';
import BooksHeader from './componenets/BooksHeader';
import BooksList from './componenets/BooksList';
import NewBookForm from './componenets/NewBookForm';

const App = () => {
    return (
        <BooksContextProvider>
            <BooksHeader />
            <BooksList />
            <NewBookForm />
        </BooksContextProvider>
    );
}
 
export default App;