import React, { useContext } from 'react';
import {BooksContext} from '../contexts/BooksContext.js';

const BooksHeader = () => {
    const { books } = useContext(BooksContext);
    return (
        <div>
            <h1>Those are your books you hui</h1>
            <div>You have {books.length} books you suka</div>
        </div>
    );
}
 
export default BooksHeader;