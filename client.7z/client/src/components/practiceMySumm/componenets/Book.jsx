import React, { useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext';
import { BOOKS_OPS } from '../contexts/reducers/BooksReducer.js';

const Book = ({ book }) => {
    const { dispatch } = useContext(BooksContext);
    return (
        <li
            key={book.id}
            onClick={() => dispatch(
                {
                    type: BOOKS_OPS.REMOVE_BOOK,
                    book: { id: book.id }
                }
            )}
        >
            <div>{book.name}</div>
            <div>{book.author}</div>
        </li>
    );
}

export default Book;