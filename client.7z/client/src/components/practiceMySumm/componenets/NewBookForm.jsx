import React, { useState, useContext } from 'react';
import {BooksContext} from '../contexts/BooksContext.js';
import {BOOKS_OPS} from '../contexts/reducers/BooksReducer.js';

const NewBookFrom = () => {
    const [name, setName] = useState('');
    const [author, setAuthor] = useState('');

    const { dispatch } = useContext(BooksContext);
    
    const addNewBook = e => {
        e.preventDefault();

        dispatch({
            type: BOOKS_OPS.ADD_BOOK,
            book: { name, author }
        });

        setName('');
        setAuthor('');
    }

    return (
        <form onSubmit={addNewBook}>
            <div>Add a new book you suka cunt</div>
            <input type="text" required value={name} onChange={e => setName(e.target.value)} placeholder="put the book name you cunti cunt" />
            <input type="text" required value={author} onChange={e => setAuthor(e.target.value)} placeholder="put the book author you suki suk" />
            <input type="submit" value="Submit you Nahui Blat Zalupa" />
        </form>
    );
}

export default NewBookFrom;