import React, { useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext.js';
import Book from './Book.jsx';

const BooksList = () => {
    const { books } = useContext(BooksContext);
    return (
        <div>
            <ul>
                {books.map(book => <Book book={book} />)}
            </ul>
        </div>
    );
}

export default BooksList;