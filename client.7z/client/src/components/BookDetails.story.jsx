import React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';

import { DisplayBookDetails } from './BookDetails.jsx';

const book = {
    name: "suka book1",
    genre: "suka genre1",
    author: {
        name: "suka author",
        books: [
            { name: "suka book1", genre: "suka genre1", id: "1" },
            { name: "suka book2", genre: "suka genre2", id: "2" }
        ]
    }
};

storiesOf('DisplayBookDetails', module)
    .addDecorator(story => (
        <div id="main">
            <div>
                {story()}
            </div>
        </div>
    ))

    .add('Loading', () => (
        <DisplayBookDetails {...{ book: undefined, loading: true, error: false }} />
    ))

    .add('Error', () => (
        <DisplayBookDetails book={undefined} loading={false} error={true} />
    ))

    .add('No book', () => (
        <DisplayBookDetails {...{ book: undefined, loading: false, error: false }} />
    ))

    .add('With book', () => (
        <DisplayBookDetails {...{ book: book, loading: false, error: false }} />
    ));
