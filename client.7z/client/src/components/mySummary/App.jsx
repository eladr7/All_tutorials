import React from 'react';
import BooksHeader from './components/BooksHeader';
import BooksList from './components/BooksList';
import BooksContextProvider from './contexts/BooksContext.js';

const HooksTutorial = () => {
    return (
        <div>
            <BooksContextProvider>
                <BooksHeader />
                <BooksList />
            </BooksContextProvider>
        </div>
    );
}

export default HooksTutorial;