import React, { useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext.js';
import NewBookForm from './NewBookForm.jsx';
import Book from './Book.jsx';

const BooksList = () => {
    const { books } = useContext(BooksContext);
    return (
        <div>
            <ul>
                {books.map(book => <Book book={book} />)}
            </ul>
            <NewBookForm />
        </div>
    );
}

export default BooksList;