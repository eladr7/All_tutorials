import React, { useState, useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext.js';
import { BOOKS_OPERATIONS } from '../contexts/reducers/BooksReducer';

const NewBookForm = () => {
    const { dispatch } = useContext(BooksContext);
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');

    const submitNewBook = e => {
        e.preventDefault();
        dispatch({
            type: BOOKS_OPERATIONS.ADD_BOOK,
            book: {
                title,
                author}
            });

        setTitle('');
        setAuthor('');
    }
    return (
        <form onSubmit={submitNewBook}>
            <label>Add a fucking new book you suka</label>
            <input type="text" required value={title} onChange={e => setTitle(e.target.value)} placeholder="put the fucking book title you cunt"/>
            <input type="text" required value={author} onChange={e => setAuthor(e.target.value)} placeholder="put the fucking book author you cunt"/>
            <input type="submit" value="Add a fucking book you cunti cunt"/>
        </form>
    );
}

export default NewBookForm;