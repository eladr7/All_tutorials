import React, { useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext.js';

const BooksHeader = () => {
    const { books } = useContext(BooksContext);
    return (
        <div>
            <h1>Suka books list you bitch</h1>
            <p>You have {books.length} books you cunt</p>
        </div>
    );
}

export default BooksHeader;