import React, { useContext } from 'react';
import { BooksContext } from '../contexts/BooksContext.js';
import { BOOKS_OPERATIONS } from '../contexts/reducers/BooksReducer';

const Book = ({ book }) => {
    const { dispatch } = useContext(BooksContext);
    return (
        <li key={book.id} onClick={() => dispatch({ type: BOOKS_OPERATIONS.REMOVE_BOOK, book: { id: book.id } })}>
            <div>{book.title}</div>
            <div>{book.author}</div>
        </li>
    );
}

export default Book;