// import uuid from 'uuid/v4';
import { v4 as uuidv4} from 'uuid';

export const BOOKS_OPERATIONS = {
    ADD_BOOK: 'ADD_BOOK',
    REMOVE_BOOK: 'REMOVE_BOOK'
};

// action = {type, book: {title, author}}
// or:
// action = {type, book: {id}}
export const BooksReducer = (state, action) => {
    switch (action.type) {
        case BOOKS_OPERATIONS.ADD_BOOK:
            return [...state, {
                title: action.book.title,
                author: action.book.author,
                id: uuidv4()}
            ];
        case BOOKS_OPERATIONS.REMOVE_BOOK:
            return state.filter(book => book.id !== action.book.id);
        default:
            return state;
    }
}