import React, { createContext, useReducer, useEffect } from 'react';
import { BooksReducer } from './reducers/BooksReducer';

export const BooksContext = createContext();

const BooksContextProvider = (props) => {
    const [books, dispatch] = useReducer(BooksReducer, [], () => {
        const booksFromStorage = localStorage.getItem('books');
        return booksFromStorage ? JSON.parse(booksFromStorage) : [];
    });

    // useEffect:
    // with no second argument    - will run on every update.
    // with an empty array []     - will run only on mount.
    // with an array like [books] - will run only when books change
    //
    // If it return a function from it - it will be performed on unmount:
    // return () => {
    //     console.log(`Unmounted`)
    // }
    useEffect(() => {
        localStorage.setItem('books', JSON.stringify(books));
    }, [books]);

    return (
        <BooksContext.Provider value={{ books, dispatch }}>
            {props.children}
        </BooksContext.Provider>
    );
}

export default BooksContextProvider;