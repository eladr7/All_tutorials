import React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';

import { DisplayBookList } from './BookList.jsx';


const books = [
    { name: "suka book1", genre: "suka genre1", id: "1" },
    { name: "suka book2", genre: "suka genre2", id: "2" },
    { name: "suka book3", genre: "suka genre3", id: "3" }
];

storiesOf('DisplayBookList', module)
    .addDecorator(story => (
        <div id="main">{story()}</div>
    ))

    .add('Loading', () => (
        <DisplayBookList {...{ books: undefined, loading: true, error: false }} />
    ))

    .add('Error', () => (
        <DisplayBookList {...{ books: undefined, loading: false, error: true }} />
    ))

    .add('No books', () => (
        <DisplayBookList {...{ books: undefined, loading: false, error: false }} />
    ))

    .add('With books', () => (
        <DisplayBookList {...{ books: books, loading: false, error: false }} />
    ));
