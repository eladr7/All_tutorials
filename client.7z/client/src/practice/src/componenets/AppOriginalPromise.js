import React from 'react';
import '../scss/App.scss';

class CuntPromise
{
    constructor()
    {
        this.ApiCall = new Promise(function(resolve, reject) {
            var request = new XMLHttpRequest();
            request.open('GET', 'https://api.github.com/users/srebalaji');
          
            request.onload = function()
            {
                if (request.status === 200)
                {
                    resolve(request.response);
                }
                else
                {
                    reject(Error(request.statusText));
                }
            }
          
            request.send();
        });
    };
    
    callTheCuntPromise()
    {
        this.ApiCall.then(function(x)
        {
            document.getElementById('response').innerHTML = x;
        }).catch(function(x)
        {
            document.getElementById('response').innerHTML = x;
        })
    }
}

const activateCuntPromiseClass = ()=>
{
    var cuntPromise = new CuntPromise();
    cuntPromise.callTheCuntPromise();
}

class App extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
          <div className="App">
            <header className="App-header">
              <div>
                <button onClick={activateCuntPromiseClass}>Make a cunt promise</button>
                <div id='response'></div>
              </div>
            </header>
          </div>
        );
    }
}

export default App;
