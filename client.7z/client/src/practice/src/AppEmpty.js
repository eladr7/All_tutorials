import React from 'react';
import './scss/App.css';

function AppEmpty() {
  return (
    <div className="App">
      <header className="App-header">
          ********************
      </header>
    </div>
  );
}

export default AppEmpty;
