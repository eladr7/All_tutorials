const fs = require('fs');
const puppeteer = require('puppeteer');
const $ = require('cheerio');

async function getLinks(url) {
    const links = await puppeteer
        .launch()
        .then(function(browser) {
            return browser.newPage();
        })
        .then(function(page) {
            return page.goto(url).then(function() {
                return page.content();
            });
        })
        .then(function(html) {
            const links = []
            $('a', html).each(function() {
                links.push($(this)[0].attribs.href);
            });

            return links;
        })
        .catch(function(err) {
            return [];
        });

    return links;
}

async function f(url, n) {
    if (n <= 0) return [];

    links = await getLinks(url).then(function(links) {
        return links;
    })
    .catch(function(error) {
        return [];
    })

    if (links.length === 0) return [];

    const T = [];
    for(let link of links) {
        const subLinks = await f(link, n - 1);

        const obj = {};
        const key = link;
        obj[key] = subLinks;

        T.push(obj);
    }

    return T;
}


const url = "https://translate.google.com/";

f(url, 2).then(function(links) {
    let linksTree = {[url]: links};
    fs.writeFile('links.txt', JSON.stringify(linksTree), function(error) { console.log(error); });
})
.catch(function(error) { console.log(error); });


// const fs = require('fs');
// const puppeteer = require('puppeteer');
// const $ = require('cheerio');
// process.setMaxListeners(0);
// async function getLinks(url) {
// 	const resLinks = await puppeteer
//   .launch()
//   .then(function(browser) {
//     return browser.newPage();
//   })
//   .then(function(page) {
//     return page.goto(url).then(function() {
//       return page.content();
//     });
//   })
//   .then(function(html) {
//   	const links = [];
//     $('a', html).each(function() {
//     	links.push($(this)[0].attribs.href);
//     });
//     return links;
//   })
//   .catch(function(err) {
//      return [];
//   });

//   return resLinks;
// }

// async function f(url, n) {
// 	if (n <= 0) return [];
// 	console.log("suka start");

// 	const links = await getLinks(url)
// 		.then(function(links) {
// 			return links;
// 		})
// 		.catch(function(error) { return []; });

// 	if (!links || links.length === 0) return [];

// 	const T = [];
// 	for(let i = 0; i < links.length; i++) {
// 		const subLinks = await f(links[i], n - 1);
// 		const obj = {};
// 		const key = links[i];
// 		obj[key] = subLinks;

// 		T.push(obj);
// 	}

// 	return T;
// }



// const url = "https://translate.google.com/";

// // const links = getLinks(url2)
// // 	.then(function(links) {return links;})
// // 	.catch(function(error) { console.log(error);});

// f(url, 2)
// .then(function(links) {
// 	console.log("suka good");
// 	fs.writeFile('links.txt', JSON.stringify(links), function(error) { 
// 		if (error) { console.log(error); }
// 	});
// })
// .catch(function(error) { console.log(error);});




// // node.js search through web page













